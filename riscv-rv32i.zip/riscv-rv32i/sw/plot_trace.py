#!/usr/bin/env python3
"""Plot PC and key register values per executed instruction from the golden model.
Writes docs/wave_<test>.png.  (Reference-model view; the RTL waveforms are in sim/waves/*.vcd
after `make sim`.)"""
import os, sys
sys.path.insert(0, os.path.dirname(__file__))
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from iss import Hart, read_hex

TESTS = {   # test -> registers to plot (index, label)
    'sum':        [(5, 't0 (i)'), (10, 'a0 (sum)')],
    'fib':        [(5, 't0 fib(n)'), (6, 't1 fib(n+1)'), (10, 'a0 result')],
    'loadstore':  [(10, 'a0 lw'), (11, 'a1 lb'), (13, 'a3 lh'), (17, 'a7'), (8, 's0')],
    'alu_branch': [(5, 't0 branch count'), (8, 's0 add'), (9, 's1 sub'), (21, 's5 sll')],
}
os.makedirs('docs', exist_ok=True)
for t, regs in TESTS.items():
    h = Hart(read_hex('sim/hex/%s.hex' % t))
    hist = []                                  # register snapshot after every instruction
    while not h.halted:
        h.step(); hist.append(list(h.x))
    n = len(hist); steps = list(range(n))
    pcs = [pc for pc, _ in h.trace[:n]]
    fig, ax = plt.subplots(2, 1, figsize=(10, 5.5), sharex=True)
    ax[0].step(steps, pcs, where='post', color='tab:blue')
    ax[0].set_ylabel('PC (byte addr)'); ax[0].grid(alpha=.3)
    ax[0].set_title('%s.S  -  golden reference model (%d instructions, 1 cycle each)' % (t, n + 1))
    for r, lab in regs:
        ax[1].step(steps, [s[r] if s[r] < 2**31 else s[r] - 2**32 for s in hist], where='post', label=lab)
    if t == 'fib': ax[1].set_yscale('symlog')
    ax[1].set_ylabel('register value'); ax[1].set_xlabel('cycle / instruction #')
    ax[1].legend(loc='upper left', fontsize=8); ax[1].grid(alpha=.3)
    fig.tight_layout(); fig.savefig('docs/wave_%s.png' % t, dpi=110); plt.close(fig)
    print('wrote docs/wave_%s.png' % t)
