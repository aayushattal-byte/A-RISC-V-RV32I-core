#!/usr/bin/env python3
"""Golden-reference RV32I instruction-set simulator (independent of the Verilog RTL).

Usage: iss.py prog.hex [--trace out.log] [--max N]
Memory map mirrors rtl/soc.v : RAM 0x0 (4 KiB), LED 0x10000000, UART 0x10000004.
Trace line format (same as tb/tb_soc.v +TRACE):  "TRACE <pc> <instr>"
"""
import sys, json, re

M32 = 0xFFFFFFFF
def sx(v, bits): v &= (1 << bits) - 1; return v - (1 << bits) if v >> (bits - 1) else v
def s32(v): return sx(v, 32)

class Hart:
    def __init__(self, words):
        self.imem = words; self.x = [0]*32; self.pc = 0
        self.ram = bytearray(4096); self.led = 0; self.uart = bytearray()
        self.halted = False; self.trace = []; self.wb = []   # wb: (step, pc, rd, value)

    def load(self, addr, n, signed):
        if addr >> 28 == 1:
            r = addr & 0xF
            v = self.led if r == 0 else 0   # UART never busy in the ISS
        else:
            v = int.from_bytes(self.ram[addr:addr+n], 'little')
        return sx(v, 8*n) & M32 if signed else v

    def store(self, addr, n, val):
        if addr >> 28 == 1:
            r = addr & 0xF
            if r == 0: self.led = val & 0xFFFF
            elif r == 4: self.uart.append(val & 0xFF)
        else:
            self.ram[addr:addr+n] = (val & ((1 << 8*n) - 1)).to_bytes(n, 'little')

    def step(self):
        i = self.imem[self.pc >> 2]; self.trace.append((self.pc, i))
        op = i & 0x7F; rd = (i>>7)&31; f3 = (i>>12)&7; rs1 = (i>>15)&31; rs2 = (i>>20)&31; f7 = i>>25
        a, b = self.x[rs1], self.x[rs2]; npc = (self.pc + 4) & M32; res = None
        if op == 0x37: res = i & 0xFFFFF000
        elif op == 0x17: res = (self.pc + (i & 0xFFFFF000)) & M32
        elif op == 0x6F:
            imm = sx(((i>>31)<<20)|(((i>>12)&0xFF)<<12)|(((i>>20)&1)<<11)|(((i>>21)&0x3FF)<<1), 21)
            res = npc; npc = (self.pc + imm) & M32
        elif op == 0x67:
            imm = sx(i>>20, 12); res = npc; npc = (a + imm) & M32 & ~1
        elif op == 0x63:
            imm = sx(((i>>31)<<12)|(((i>>7)&1)<<11)|(((i>>25)&0x3F)<<5)|(((i>>8)&0xF)<<1), 13)
            t = {0: a == b, 1: a != b, 4: s32(a) < s32(b), 5: s32(a) >= s32(b),
                 6: a < b, 7: a >= b}[f3]
            if t: npc = (self.pc + imm) & M32
        elif op == 0x03:
            addr = (a + sx(i>>20, 12)) & M32
            n, sg = {0:(1,1),1:(2,1),2:(4,0),4:(1,0),5:(2,0)}[f3]
            res = self.load(addr, n, sg)
        elif op == 0x23:
            imm = sx(((i>>25)<<5)|((i>>7)&0x1F), 12)
            self.store((a + imm) & M32, {0:1,1:2,2:4}[f3], b)
        elif op in (0x13, 0x33):
            if op == 0x13:
                imm = sx(i>>20, 12); bb = imm & M32; alt = (f7 == 0x20) and f3 == 5
            else:
                bb = b; alt = (f7 == 0x20)
            sh = bb & 31
            if   f3 == 0: res = (a - bb) & M32 if (op == 0x33 and alt) else (a + bb) & M32
            elif f3 == 1: res = (a << sh) & M32
            elif f3 == 2: res = int(s32(a) < s32(bb))
            elif f3 == 3: res = int(a < bb)
            elif f3 == 4: res = a ^ bb
            elif f3 == 5: res = (s32(a) >> sh) & M32 if alt else a >> sh
            elif f3 == 6: res = a | bb
            elif f3 == 7: res = a & bb
        elif op == 0x0F: pass
        elif op == 0x73: self.halted = True; return
        else: raise RuntimeError("illegal instr %08x at pc %08x" % (i, self.pc))
        if res is not None and rd != 0:
            self.x[rd] = res & M32; self.wb.append((len(self.trace), self.pc, rd, res & M32))
        self.pc = npc

def read_hex(path):
    ws = []
    for l in open(path):
        l = l.split('//')[0].strip()
        if l: ws.append(int(l, 16))
    return ws + [0x13] * (1024 - len(ws))

if __name__ == '__main__':
    args = sys.argv[1:]
    if not args: sys.exit(__doc__)
    hexf = args[0]; tr = args[args.index('--trace')+1] if '--trace' in args else None
    mx = int(args[args.index('--max')+1]) if '--max' in args else 1_000_000
    h = Hart(read_hex(hexf))
    while not h.halted and len(h.trace) < mx: h.step()
    if tr:
        with open(tr, 'w') as f:
            for pc, i in h.trace: f.write("TRACE %08x %08x\n" % (pc, i))
    print(json.dumps({'halted': h.halted, 'instructions': len(h.trace),
        'regs': {('x%d' % k): '0x%08x' % v for k, v in enumerate(h.x) if v},
        'ram_nonzero': {('0x%03x' % a): '0x%08x' % int.from_bytes(h.ram[a:a+4], 'little')
                        for a in range(0, 4096, 4) if h.ram[a:a+4] != b'\0\0\0\0'},
        'led': h.led, 'uart': h.uart.decode('latin1')}, indent=1))
