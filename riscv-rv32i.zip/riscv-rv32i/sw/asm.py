#!/usr/bin/env python3
"""Tiny two-pass RV32I assembler (no external toolchain needed).

Usage: asm.py prog.S out.hex
Supports all RV32I base instructions plus pseudos:
  nop mv li j jr ret call beqz bnez not neg
Output: one 32-bit word per line ($readmemh format) with a comment showing source.
"""
import re, sys

ABI = {'zero':0,'ra':1,'sp':2,'gp':3,'tp':4,'t0':5,'t1':6,'t2':7,'s0':8,'fp':8,'s1':9,
       'a0':10,'a1':11,'a2':12,'a3':13,'a4':14,'a5':15,'a6':16,'a7':17,
       's2':18,'s3':19,'s4':20,'s5':21,'s6':22,'s7':23,'s8':24,'s9':25,'s10':26,'s11':27,
       't3':28,'t4':29,'t5':30,'t6':31}
for i in range(32): ABI['x%d' % i] = i

R  = {'add':(0,0),'sub':(0x20,0),'sll':(0,1),'slt':(0,2),'sltu':(0,3),'xor':(0,4),
      'srl':(0,5),'sra':(0x20,5),'or':(0,6),'and':(0,7)}
IA = {'addi':0,'slti':2,'sltiu':3,'xori':4,'ori':6,'andi':7}
SH = {'slli':(0,1),'srli':(0,5),'srai':(0x20,5)}
LD = {'lb':0,'lh':1,'lw':2,'lbu':4,'lhu':5}
ST = {'sb':0,'sh':1,'sw':2}
BR = {'beq':0,'bne':1,'blt':4,'bge':5,'bltu':6,'bgeu':7}

def reg(s):
    s = s.strip()
    if s not in ABI: raise ValueError("bad register '%s'" % s)
    return ABI[s]

def num(s):
    s = s.strip()
    if len(s) >= 3 and s[0] == "'" and s[-1] == "'":
        return ord(s[1:-1].encode().decode('unicode_escape'))
    return int(s, 0)

def split_ops(s):
    return [o.strip() for o in s.split(',')] if s.strip() else []

def li_parts(v):
    v &= 0xFFFFFFFF
    sv = v - (1 << 32) if v >= (1 << 31) else v
    if -2048 <= sv <= 2047:
        return [('addi', sv)]
    lo = ((v & 0xFFF) ^ 0x800) - 0x800
    hi = ((v - lo) >> 12) & 0xFFFFF
    parts = [('lui', hi)]
    if lo: parts.append(('addi', lo))
    return parts

def expand(mn, ops):
    """Expand pseudo-instructions -> list of (mnemonic, operands)."""
    if mn == 'nop':  return [('addi', ['zero', 'zero', '0'])]
    if mn == 'mv':   return [('addi', [ops[0], ops[1], '0'])]
    if mn == 'not':  return [('xori', [ops[0], ops[1], '-1'])]
    if mn == 'neg':  return [('sub',  [ops[0], 'zero', ops[1]])]
    if mn == 'j':    return [('jal',  ['zero', ops[0]])]
    if mn == 'jr':   return [('jalr', ['zero', ops[0], '0'])]
    if mn == 'ret':  return [('jalr', ['zero', 'ra', '0'])]
    if mn == 'call': return [('jal',  ['ra', ops[0]])]
    if mn == 'beqz': return [('beq',  [ops[0], 'zero', ops[1]])]
    if mn == 'bnez': return [('bne',  [ops[0], 'zero', ops[1]])]
    if mn == 'ecall' or mn == 'ebreak': return [(mn, [])]
    if mn == 'li':
        out = []
        for m, v in li_parts(num(ops[1])):
            if m == 'addi': out.append(('addi', [ops[0], 'zero' if len(out) == 0 else ops[0], str(v)]))
            else:           out.append(('lui',  [ops[0], str(v)]))
        return out
    return [(mn, ops)]

def enc_r(f7, rs2, rs1, f3, rd, op): return (f7<<25)|(rs2<<20)|(rs1<<15)|(f3<<12)|(rd<<7)|op
def enc_i(imm, rs1, f3, rd, op):
    if not -2048 <= imm <= 2047: raise ValueError("I-imm out of range: %d" % imm)
    return ((imm & 0xFFF)<<20)|(rs1<<15)|(f3<<12)|(rd<<7)|op
def enc_s(imm, rs2, rs1, f3):
    if not -2048 <= imm <= 2047: raise ValueError("S-imm out of range: %d" % imm)
    imm &= 0xFFF
    return ((imm>>5)<<25)|(rs2<<20)|(rs1<<15)|(f3<<12)|((imm&0x1F)<<7)|0x23
def enc_b(off, rs2, rs1, f3):
    if off % 2 or not -4096 <= off <= 4094: raise ValueError("B offset bad: %d" % off)
    o = off & 0x1FFF
    return (((o>>12)&1)<<31)|(((o>>5)&0x3F)<<25)|(rs2<<20)|(rs1<<15)|(f3<<12)|(((o>>1)&0xF)<<8)|(((o>>11)&1)<<7)|0x63
def enc_u(imm20, rd, op): return ((imm20 & 0xFFFFF)<<12)|(rd<<7)|op
def enc_j(off, rd):
    if off % 2 or not -(1<<20) <= off < (1<<20): raise ValueError("J offset bad: %d" % off)
    o = off & 0x1FFFFF
    return (((o>>20)&1)<<31)|(((o>>1)&0x3FF)<<21)|(((o>>11)&1)<<20)|(((o>>12)&0xFF)<<12)|(rd<<7)|0x6F

def assemble(text):
    items, labels, addr = [], {}, 0
    for lineno, raw in enumerate(text.splitlines(), 1):
        line = raw.split('#')[0].strip()
        while ':' in line:
            lab, line = line.split(':', 1)
            labels[lab.strip()] = addr
            line = line.strip()
        if not line: continue
        mn, _, rest = line.partition(' ')
        mn = mn.strip().lower()
        for m, o in expand(mn, split_ops(rest)):
            items.append((addr, m, o, raw.strip(), lineno))
            addr += 4
    words = []
    for addr, mn, ops, src, lineno in items:
        try:
            def tgt(s): return labels[s] - addr if s in labels else num(s)
            if mn in R:
                f7, f3 = R[mn]; w = enc_r(f7, reg(ops[2]), reg(ops[1]), f3, reg(ops[0]), 0x33)
            elif mn in IA:
                w = enc_i(num(ops[2]), reg(ops[1]), IA[mn], reg(ops[0]), 0x13)
            elif mn in SH:
                f7, f3 = SH[mn]; sh = num(ops[2])
                assert 0 <= sh < 32
                w = enc_r(f7, sh, reg(ops[1]), f3, reg(ops[0]), 0x13)
            elif mn in LD:
                m = re.match(r'(.+)\((\w+)\)$', ops[1].strip())
                w = enc_i(num(m.group(1)), reg(m.group(2)), LD[mn], reg(ops[0]), 0x03)
            elif mn in ST:
                m = re.match(r'(.+)\((\w+)\)$', ops[1].strip())
                w = enc_s(num(m.group(1)), reg(ops[0]), reg(m.group(2)), ST[mn])
            elif mn in BR:
                w = enc_b(tgt(ops[2]), reg(ops[1]), reg(ops[0]), BR[mn])
            elif mn == 'lui':   w = enc_u(num(ops[1]), reg(ops[0]), 0x37)
            elif mn == 'auipc': w = enc_u(num(ops[1]), reg(ops[0]), 0x17)
            elif mn == 'jal':   w = enc_j(tgt(ops[1]), reg(ops[0]))
            elif mn == 'jalr':  w = enc_i(num(ops[2]), reg(ops[1]), 0, reg(ops[0]), 0x67)
            elif mn == 'ecall': w = 0x00000073
            elif mn == 'ebreak':w = 0x00100073
            else: raise ValueError("unknown mnemonic '%s'" % mn)
        except Exception as e:
            sys.exit("asm error line %d (%s): %s" % (lineno, src, e))
        words.append((addr, w, src))
    return words

if __name__ == '__main__':
    if len(sys.argv) != 3: sys.exit(__doc__)
    words = assemble(open(sys.argv[1]).read())
    with open(sys.argv[2], 'w') as f:
        for addr, w, src in words:
            f.write("%08x // %04x: %s\n" % (w, addr, src))
    print("%s -> %s (%d words)" % (sys.argv[1], sys.argv[2], len(words)))
