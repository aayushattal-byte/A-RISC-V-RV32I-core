// -----------------------------------------------------------------------------
// fpga_top.v - Spartan-7 top level (target: Digilent Arty S7, 100 MHz oscillator)
//
//   * MMCM generates a 50 MHz CPU clock from the 100 MHz board clock
//     (the single-cycle datapath is too long for reliable 100 MHz on a -1 part)
//   * btn_rst (active high) + MMCM lock -> synchronised reset
//   * led[3:0]  = low nibble of the SoC LED register
//   * uart_txd  = USB-UART bridge (115200 8N1)
// -----------------------------------------------------------------------------
module fpga_top #(
    parameter INIT_FILE = "demo_uart_led.hex"   // build.tcl overrides with an absolute path
) (
    input        clk100,
    input        btn_rst,
    output [3:0] led,
    output       uart_txd
);
    // ---- clocking: 100 MHz -> 50 MHz
    wire clk_fb, clk_fb_buf, clk50_unbuf, clk50, locked;

    MMCME2_BASE #(
        .BANDWIDTH("OPTIMIZED"),
        .CLKIN1_PERIOD(10.0),
        .CLKFBOUT_MULT_F(10.0),               // VCO = 1000 MHz
        .DIVCLK_DIVIDE(1),
        .CLKOUT0_DIVIDE_F(20.0)               // 1000 / 20 = 50 MHz
    ) u_mmcm (
        .CLKIN1(clk100), .CLKFBIN(clk_fb_buf), .CLKFBOUT(clk_fb),
        .CLKOUT0(clk50_unbuf), .LOCKED(locked),
        .PWRDWN(1'b0), .RST(1'b0)
    );
    BUFG u_bufg_fb  (.I(clk_fb),       .O(clk_fb_buf));
    BUFG u_bufg_cpu (.I(clk50_unbuf),  .O(clk50));

    // ---- reset synchroniser (async assert, sync release)
    reg [2:0] rst_sync = 3'b111;
    always @(posedge clk50 or posedge btn_rst) begin
        if (btn_rst)        rst_sync <= 3'b111;
        else if (!locked)   rst_sync <= 3'b111;
        else                rst_sync <= {rst_sync[1:0], 1'b0};
    end
    wire rst = rst_sync[2];

    // ---- SoC
    wire [15:0] leds16;
    wire        halted;

    soc #(
        .INIT_FILE(INIT_FILE),
        .CLKS_PER_BIT(434)                    // 50 MHz / 115200
    ) u_soc (
        .clk(clk50), .rst(rst), .leds(leds16),
        .uart_txd(uart_txd), .halted(halted)
    );

    assign led = leds16[3:0];
endmodule
