// -----------------------------------------------------------------------------
// uart_tx.v - 8N1 UART transmitter
// Pulse `start` for one clock while !busy to send `data`.
// -----------------------------------------------------------------------------
module uart_tx #(
    parameter CLKS_PER_BIT = 434              // 50 MHz / 115200
) (
    input        clk,
    input        rst,
    input        start,
    input  [7:0] data,
    output reg   tx,
    output       busy
);
    reg        active;
    reg [9:0]  frame;                         // {stop, d7..d0, start}
    reg [3:0]  bit_idx;
    reg [15:0] cnt;

    assign busy = active;

    always @(posedge clk) begin
        if (rst) begin
            active  <= 1'b0;
            tx      <= 1'b1;
            cnt     <= 16'd0;
            bit_idx <= 4'd0;
            frame   <= 10'h3FF;
        end else if (!active) begin
            tx <= 1'b1;
            if (start) begin
                frame   <= {1'b1, data, 1'b0};
                active  <= 1'b1;
                cnt     <= 16'd0;
                bit_idx <= 4'd0;
                tx      <= 1'b0;              // start bit
            end
        end else begin
            if (cnt == CLKS_PER_BIT - 1) begin
                cnt <= 16'd0;
                if (bit_idx == 4'd9) begin
                    active <= 1'b0;           // stop bit finished
                    tx     <= 1'b1;
                end else begin
                    bit_idx <= bit_idx + 4'd1;
                    tx      <= frame[bit_idx + 4'd1];
                end
            end else begin
                cnt <= cnt + 16'd1;
            end
        end
    end
endmodule
