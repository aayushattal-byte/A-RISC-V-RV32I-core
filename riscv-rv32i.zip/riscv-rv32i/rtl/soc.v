// -----------------------------------------------------------------------------
// soc.v - RV32I core + instruction ROM + data RAM + LED/UART peripherals
//
// Memory map (data side)
//   0x0000_0000 - 0x0000_0FFF   data RAM (4 KiB)
//   0x1000_0000                 LED register   (R/W, bits [15:0])
//   0x1000_0004                 UART TX        (W: send byte, R: bit0 = busy)
// Instruction ROM is a separate (Harvard) space starting at 0x0.
// -----------------------------------------------------------------------------
module soc #(
    parameter INIT_FILE    = "sim/hex/demo_uart_led.hex",
    parameter CLKS_PER_BIT = 434
) (
    input         clk,
    input         rst,
    output [15:0] leds,
    output        uart_txd,
    output        halted
);
    wire [31:0] imem_addr, imem_data;
    wire [31:0] dmem_addr, dmem_wdata, dmem_rdata;
    wire [3:0]  dmem_wstrb;
    wire        dmem_ren;

    riscv_core u_core (
        .clk(clk), .rst(rst),
        .imem_addr(imem_addr), .imem_data(imem_data),
        .dmem_addr(dmem_addr), .dmem_wdata(dmem_wdata), .dmem_wstrb(dmem_wstrb),
        .dmem_ren(dmem_ren), .dmem_rdata(dmem_rdata),
        .halted(halted)
    );

    imem #(.ADDR_BITS(10), .INIT_FILE(INIT_FILE)) u_imem (
        .addr(imem_addr), .rdata(imem_data)
    );

    // ---- address decode
    wire ram_sel  = (dmem_addr[31:12] == 20'h00000);
    wire mmio_sel = (dmem_addr[31:28] == 4'h1);
    wire [1:0] mmio_reg = dmem_addr[3:2];

    wire [31:0] ram_rdata;
    dmem #(.ADDR_BITS(10)) u_dmem (
        .clk(clk), .addr(dmem_addr), .wdata(dmem_wdata),
        .wstrb(dmem_wstrb & {4{ram_sel}}), .rdata(ram_rdata)
    );

    // ---- peripherals
    reg [15:0] led_q;
    wire       mmio_we   = mmio_sel && (|dmem_wstrb);
    wire       uart_busy;
    wire       uart_start = mmio_we && (mmio_reg == 2'd1) && !uart_busy;

    always @(posedge clk) begin
        if (rst)                                   led_q <= 16'b0;
        else if (mmio_we && (mmio_reg == 2'd0))    led_q <= dmem_wdata[15:0];
    end

    uart_tx #(.CLKS_PER_BIT(CLKS_PER_BIT)) u_uart (
        .clk(clk), .rst(rst), .start(uart_start),
        .data(dmem_wdata[7:0]), .tx(uart_txd), .busy(uart_busy)
    );

    reg [31:0] mmio_rdata;
    always @* begin
        case (mmio_reg)
            2'd0   : mmio_rdata = {16'b0, led_q};
            2'd1   : mmio_rdata = {31'b0, uart_busy};
            default: mmio_rdata = 32'b0;
        endcase
    end

    assign dmem_rdata = mmio_sel ? mmio_rdata : ram_rdata;
    assign leds       = led_q;
endmodule
