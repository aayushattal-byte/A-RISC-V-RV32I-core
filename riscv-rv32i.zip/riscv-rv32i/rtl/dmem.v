// -----------------------------------------------------------------------------
// dmem.v - data RAM, byte-write strobes, synchronous write, asynchronous read
// -----------------------------------------------------------------------------
module dmem #(
    parameter ADDR_BITS = 10                  // 2**10 words = 4 KiB
) (
    input         clk,
    input  [31:0] addr,
    input  [31:0] wdata,
    input  [3:0]  wstrb,
    output [31:0] rdata
);
    reg [31:0] mem [0:(1<<ADDR_BITS)-1];
    integer i;
    initial begin
        for (i = 0; i < (1<<ADDR_BITS); i = i + 1) mem[i] = 32'b0;
    end

    wire [ADDR_BITS-1:0] widx = addr[ADDR_BITS+1:2];

    always @(posedge clk) begin
        if (wstrb[0]) mem[widx][7:0]   <= wdata[7:0];
        if (wstrb[1]) mem[widx][15:8]  <= wdata[15:8];
        if (wstrb[2]) mem[widx][23:16] <= wdata[23:16];
        if (wstrb[3]) mem[widx][31:24] <= wdata[31:24];
    end

    assign rdata = mem[widx];
endmodule
