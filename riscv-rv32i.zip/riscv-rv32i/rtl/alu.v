// -----------------------------------------------------------------------------
// alu.v - RV32I arithmetic/logic unit (purely combinational)
// op encoding = {funct7[5], funct3}
// -----------------------------------------------------------------------------
module alu (
    input      [31:0] a,
    input      [31:0] b,
    input      [3:0]  op,
    output reg [31:0] y
);
    localparam ALU_ADD  = 4'b0000;
    localparam ALU_SUB  = 4'b1000;
    localparam ALU_SLL  = 4'b0001;
    localparam ALU_SLT  = 4'b0010;
    localparam ALU_SLTU = 4'b0011;
    localparam ALU_XOR  = 4'b0100;
    localparam ALU_SRL  = 4'b0101;
    localparam ALU_SRA  = 4'b1101;
    localparam ALU_OR   = 4'b0110;
    localparam ALU_AND  = 4'b0111;

    wire signed [31:0] a_s   = a;
    wire signed [31:0] b_s   = b;
    wire        [4:0]  shamt = b[4:0];
    wire signed [31:0] sra_r = a_s >>> shamt;

    always @* begin
        case (op)
            ALU_ADD : y = a + b;
            ALU_SUB : y = a - b;
            ALU_SLL : y = a << shamt;
            ALU_SLT : y = {31'b0, (a_s < b_s)};
            ALU_SLTU: y = {31'b0, (a < b)};
            ALU_XOR : y = a ^ b;
            ALU_SRL : y = a >> shamt;
            ALU_SRA : y = sra_r;
            ALU_OR  : y = a | b;
            ALU_AND : y = a & b;
            default : y = 32'b0;
        endcase
    end
endmodule
