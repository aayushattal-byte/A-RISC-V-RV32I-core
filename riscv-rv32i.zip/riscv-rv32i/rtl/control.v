// -----------------------------------------------------------------------------
// control.v - main decoder for the single-cycle RV32I core
// -----------------------------------------------------------------------------
module control (
    input      [31:0] instr,
    output reg        reg_write,
    output reg        alu_src_a_pc,   // 1: ALU operand A = PC (AUIPC), 0: rs1
    output reg        alu_src_b_imm,  // 1: ALU operand B = imm,         0: rs2
    output reg        mem_read,
    output reg        mem_write,
    output reg        branch,
    output reg        jal,
    output reg        jalr,
    output reg [1:0]  wb_sel,         // 00 ALU, 01 MEM, 10 PC+4, 11 IMM (LUI)
    output reg [3:0]  alu_op,
    output reg        halt            // ECALL / EBREAK
);
    localparam OP_LUI    = 7'b0110111;
    localparam OP_AUIPC  = 7'b0010111;
    localparam OP_JAL    = 7'b1101111;
    localparam OP_JALR   = 7'b1100111;
    localparam OP_BRANCH = 7'b1100011;
    localparam OP_LOAD   = 7'b0000011;
    localparam OP_STORE  = 7'b0100011;
    localparam OP_IMM    = 7'b0010011;
    localparam OP_REG    = 7'b0110011;
    localparam OP_FENCE  = 7'b0001111;
    localparam OP_SYSTEM = 7'b1110011;

    wire [6:0] opcode = instr[6:0];
    wire [2:0] funct3 = instr[14:12];
    wire       f7b5   = instr[30];

    always @* begin
        // defaults = NOP-like behaviour
        reg_write     = 1'b0;
        alu_src_a_pc  = 1'b0;
        alu_src_b_imm = 1'b0;
        mem_read      = 1'b0;
        mem_write     = 1'b0;
        branch        = 1'b0;
        jal           = 1'b0;
        jalr          = 1'b0;
        wb_sel        = 2'b00;
        alu_op        = 4'b0000;
        halt          = 1'b0;

        case (opcode)
            OP_LUI: begin
                reg_write = 1'b1;
                wb_sel    = 2'b11;
            end
            OP_AUIPC: begin
                reg_write     = 1'b1;
                alu_src_a_pc  = 1'b1;
                alu_src_b_imm = 1'b1;
            end
            OP_JAL: begin
                reg_write = 1'b1;
                jal       = 1'b1;
                wb_sel    = 2'b10;
            end
            OP_JALR: begin
                reg_write     = 1'b1;
                jalr          = 1'b1;
                alu_src_b_imm = 1'b1;   // target = rs1 + imm
                wb_sel        = 2'b10;
            end
            OP_BRANCH: begin
                branch = 1'b1;
            end
            OP_LOAD: begin
                reg_write     = 1'b1;
                alu_src_b_imm = 1'b1;
                mem_read      = 1'b1;
                wb_sel        = 2'b01;
            end
            OP_STORE: begin
                alu_src_b_imm = 1'b1;
                mem_write     = 1'b1;
            end
            OP_IMM: begin
                reg_write     = 1'b1;
                alu_src_b_imm = 1'b1;
                // only SRLI/SRAI use funct7[5]; for ADDI etc. bit 30 is immediate data
                alu_op = (funct3 == 3'b101) ? {f7b5, funct3} : {1'b0, funct3};
            end
            OP_REG: begin
                reg_write = 1'b1;
                alu_op    = {f7b5, funct3};
            end
            OP_FENCE: begin
                // treated as NOP
            end
            OP_SYSTEM: begin
                halt = 1'b1;            // ECALL/EBREAK stop the core (used by testbench)
            end
            default: begin
                // unknown opcode: behaves as NOP
            end
        endcase
    end
endmodule
