// -----------------------------------------------------------------------------
// imem.v - instruction ROM (word addressed, asynchronous read)
// Initialised from a $readmemh file; unused words are filled with NOP.
// -----------------------------------------------------------------------------
module imem #(
    parameter ADDR_BITS = 10,                 // 2**10 words = 4 KiB
    parameter INIT_FILE = "program.hex"
) (
    input  [31:0] addr,
    output [31:0] rdata
);
    reg [31:0] mem [0:(1<<ADDR_BITS)-1];
    integer i;
    initial begin
        for (i = 0; i < (1<<ADDR_BITS); i = i + 1) mem[i] = 32'h00000013; // NOP
        $readmemh(INIT_FILE, mem);
    end
    assign rdata = mem[addr[ADDR_BITS+1:2]];
endmodule
