// -----------------------------------------------------------------------------
// riscv_core.v - Single-cycle RV32I core
//
//   * Harvard style: instruction ROM port + data port
//   * Instruction fetch is combinational (imem_addr -> imem_data)
//   * Data memory read is combinational, write is synchronous (word + byte strobes)
//   * Misaligned loads/stores are NOT supported (software must align)
//   * ECALL/EBREAK assert `halted` and freeze the PC
// -----------------------------------------------------------------------------
module riscv_core (
    input         clk,
    input         rst,                // synchronous, active high

    output [31:0] imem_addr,
    input  [31:0] imem_data,

    output [31:0] dmem_addr,          // byte address
    output [31:0] dmem_wdata,
    output [3:0]  dmem_wstrb,
    output        dmem_ren,
    input  [31:0] dmem_rdata,         // raw 32-bit word at dmem_addr[..:2]

    output        halted
);
    // ------------------------------------------------------------------ fetch
    reg  [31:0] pc;
    wire [31:0] instr = imem_data;
    assign imem_addr  = pc;

    wire [31:0] pc_plus4 = pc + 32'd4;

    // ----------------------------------------------------------------- decode
    wire [4:0] rs1 = instr[19:15];
    wire [4:0] rs2 = instr[24:20];
    wire [4:0] rd  = instr[11:7];
    wire [2:0] funct3 = instr[14:12];

    wire        reg_write, alu_src_a_pc, alu_src_b_imm;
    wire        mem_read, mem_write, branch, jal, jalr, halt;
    wire [1:0]  wb_sel;
    wire [3:0]  alu_op;

    control u_ctrl (
        .instr(instr), .reg_write(reg_write), .alu_src_a_pc(alu_src_a_pc),
        .alu_src_b_imm(alu_src_b_imm), .mem_read(mem_read), .mem_write(mem_write),
        .branch(branch), .jal(jal), .jalr(jalr), .wb_sel(wb_sel),
        .alu_op(alu_op), .halt(halt)
    );

    wire [31:0] imm;
    imm_gen u_imm (.instr(instr), .imm(imm));

    wire [31:0] rs1_data, rs2_data;
    reg  [31:0] wb_data;

    regfile u_rf (
        .clk(clk), .we(reg_write && !halt), .waddr(rd), .wdata(wb_data),
        .raddr1(rs1), .raddr2(rs2), .rdata1(rs1_data), .rdata2(rs2_data)
    );

    // ---------------------------------------------------------------- execute
    wire [31:0] alu_a = alu_src_a_pc  ? pc  : rs1_data;
    wire [31:0] alu_b = alu_src_b_imm ? imm : rs2_data;
    wire [31:0] alu_y;

    alu u_alu (.a(alu_a), .b(alu_b), .op(alu_op), .y(alu_y));

    // branch comparator
    wire eq  = (rs1_data == rs2_data);
    wire lt  = ($signed(rs1_data) < $signed(rs2_data));
    wire ltu = (rs1_data < rs2_data);

    reg take_branch;
    always @* begin
        case (funct3)
            3'b000 : take_branch = eq;      // BEQ
            3'b001 : take_branch = ~eq;     // BNE
            3'b100 : take_branch = lt;      // BLT
            3'b101 : take_branch = ~lt;     // BGE
            3'b110 : take_branch = ltu;     // BLTU
            3'b111 : take_branch = ~ltu;    // BGEU
            default: take_branch = 1'b0;
        endcase
    end

    // next PC
    wire [31:0] pc_target = pc + imm;                 // JAL / branch target
    wire [31:0] jalr_tgt  = {alu_y[31:1], 1'b0};      // (rs1 + imm) & ~1

    reg [31:0] next_pc;
    always @* begin
        if (halt)                          next_pc = pc;
        else if (jal || (branch && take_branch)) next_pc = pc_target;
        else if (jalr)                     next_pc = jalr_tgt;
        else                               next_pc = pc_plus4;
    end

    always @(posedge clk) begin
        if (rst) pc <= 32'b0;
        else     pc <= next_pc;
    end

    assign halted = halt;

    // ----------------------------------------------------------------- memory
    assign dmem_addr = alu_y;
    assign dmem_ren  = mem_read;
    wire [1:0] byte_off = alu_y[1:0];

    reg [31:0] st_data;
    reg [3:0]  st_strb;
    always @* begin
        case (funct3[1:0])
            2'b00: begin                                   // SB
                st_data = {4{rs2_data[7:0]}};
                st_strb = 4'b0001 << byte_off;
            end
            2'b01: begin                                   // SH
                st_data = {2{rs2_data[15:0]}};
                st_strb = byte_off[1] ? 4'b1100 : 4'b0011;
            end
            default: begin                                 // SW
                st_data = rs2_data;
                st_strb = 4'b1111;
            end
        endcase
    end
    assign dmem_wdata = st_data;
    assign dmem_wstrb = mem_write ? st_strb : 4'b0000;

    // load alignment / sign extension
    wire [31:0] ld_shift = dmem_rdata >> {byte_off, 3'b000};
    reg  [31:0] ld_data;
    always @* begin
        case (funct3)
            3'b000 : ld_data = {{24{ld_shift[7]}},  ld_shift[7:0]};    // LB
            3'b001 : ld_data = {{16{ld_shift[15]}}, ld_shift[15:0]};   // LH
            3'b010 : ld_data = ld_shift;                               // LW
            3'b100 : ld_data = {24'b0, ld_shift[7:0]};                 // LBU
            3'b101 : ld_data = {16'b0, ld_shift[15:0]};                // LHU
            default: ld_data = ld_shift;
        endcase
    end

    // -------------------------------------------------------------- writeback
    always @* begin
        case (wb_sel)
            2'b00  : wb_data = alu_y;
            2'b01  : wb_data = ld_data;
            2'b10  : wb_data = pc_plus4;
            default: wb_data = imm;
        endcase
    end
endmodule
