// -----------------------------------------------------------------------------
// tb_soc.v - self-checking testbench for the RV32I SoC
//
// Run (from repo root):
//   vvp sim/build/tb.vvp +TEST=sum +HEX=sim/hex/sum.hex +VCD=sim/waves/sum.vcd +TRACE
//
//   +TEST=<sum|fib|loadstore|alu_branch|demo>   selects the expected results
//   +HEX=<file>                                  program image
//   +VCD=<file>                                  waveform output (optional)
//   +TRACE                                       print "TRACE <pc> <instr>" per instruction
// -----------------------------------------------------------------------------
`timescale 1ns/1ps

module tb_soc;
    localparam CLK_NS = 10;                 // 100 MHz simulation clock
    localparam CPB    = 868;                // clocks per UART bit (100 MHz / 115200)
    localparam BIT_NS = CPB * CLK_NS;

    reg clk = 1'b0;
    reg rst = 1'b1;
    always #(CLK_NS/2) clk = ~clk;

    wire [15:0] leds;
    wire        uart_txd;
    wire        halted;

    soc #(.INIT_FILE("sim/hex/demo_uart_led.hex"), .CLKS_PER_BIT(CPB)) dut (
        .clk(clk), .rst(rst), .leds(leds), .uart_txd(uart_txd), .halted(halted)
    );

    // ------------------------------------------------------------ bookkeeping
    integer errors = 0;
    integer checks = 0;
    reg [8*32-1:0] test;
    reg [8*128-1:0] hexfile;
    reg [8*128-1:0] vcdfile;
    reg trace_en;
    integer cyc;

    task chk_reg(input integer r, input [31:0] exp);
        reg [31:0] got;
        begin
            got = (r == 0) ? 32'b0 : dut.u_core.u_rf.regs[r];
            checks = checks + 1;
            if (got !== exp) begin
                errors = errors + 1;
                $display("FAIL: x%0d = 0x%08h, expected 0x%08h", r, got, exp);
            end else
                $display("PASS: x%0d = 0x%08h", r, got);
        end
    endtask

    task chk_mem(input integer w, input [31:0] exp);
        reg [31:0] got;
        begin
            got = dut.u_dmem.mem[w];
            checks = checks + 1;
            if (got !== exp) begin
                errors = errors + 1;
                $display("FAIL: mem[%0d] (addr 0x%03h) = 0x%08h, expected 0x%08h", w, w*4, got, exp);
            end else
                $display("PASS: mem[%0d] (addr 0x%03h) = 0x%08h", w, w*4, got);
        end
    endtask

    // ------------------------------------------------------ instruction trace
    reg traced_halt = 1'b0;
    always @(posedge clk) begin
        if (trace_en && !rst && !traced_halt) begin
            $display("TRACE %08h %08h", dut.u_core.pc, dut.u_core.instr);
            if (halted) traced_halt <= 1'b1;
        end
    end

    // ---------------------------------------------------------- UART receiver
    reg [7:0] rx_buf [0:63];
    reg [7:0] rx_shift;
    integer   rx_n = 0;
    integer   ub;
    initial begin
        forever begin
            @(negedge uart_txd);            // start bit
            #(BIT_NS/2);                    // middle of start bit
            for (ub = 0; ub < 8; ub = ub + 1) begin
                #(BIT_NS);
                rx_shift[ub] = uart_txd;
            end
            #(BIT_NS);                      // middle of stop bit
            rx_buf[rx_n] = rx_shift;
            rx_n = rx_n + 1;
        end
    end

    // ------------------------------------------------------------------ main
    reg [8*19-1:0] exp_text = "RV32I OK fib(10)=55";
    integer i;
    initial begin
        if (!$value$plusargs("TEST=%s", test)) test = "demo";
        if (!$value$plusargs("HEX=%s",  hexfile)) hexfile = "sim/hex/demo_uart_led.hex";
        trace_en = $test$plusargs("TRACE");
        if ($value$plusargs("VCD=%s", vcdfile)) begin
            $dumpfile(vcdfile);
            $dumpvars(0, tb_soc);
        end

        #1 $readmemh(hexfile, dut.u_imem.mem);   // load program after imem's own init
        repeat (4) @(posedge clk);
        #1 rst = 1'b0;

        if (test == "demo") begin
            // wait for the 21-character banner or time out
            cyc = 0;
            while (rx_n < 21 && cyc < 400000) begin
                @(posedge clk);
                cyc = cyc + 1;
            end
            #(BIT_NS);
            checks = checks + 1;
            if (rx_n < 21) begin
                errors = errors + 1;
                $display("FAIL: UART produced only %0d characters", rx_n);
            end else begin
                for (i = 0; i < 19; i = i + 1) begin
                    checks = checks + 1;
                    if (rx_buf[i] !== exp_text[8*(18-i) +: 8]) begin
                        errors = errors + 1;
                        $display("FAIL: uart[%0d] = 0x%02h, expected 0x%02h", i, rx_buf[i], exp_text[8*(18-i) +: 8]);
                    end
                end
                checks = checks + 2;
                if (rx_buf[19] !== 8'h0D || rx_buf[20] !== 8'h0A) begin
                    errors = errors + 1;
                    $display("FAIL: line ending is not CR LF");
                end
                $write("UART OUTPUT: ");
                for (i = 0; i < 19; i = i + 1) $write("%c", rx_buf[i]);
                $write("\n");
                $display("PASS: UART text matches \"RV32I OK fib(10)=55\" + CRLF");
            end
            checks = checks + 1;
            if (leds !== 16'd55) begin
                errors = errors + 1;
                $display("FAIL: leds = %0d, expected 55", leds);
            end else
                $display("PASS: leds = %0d (0b%016b)", leds, leds);
        end else begin
            cyc = 0;
            while (!halted && cyc < 20000) begin
                @(posedge clk);
                cyc = cyc + 1;
            end
            @(posedge clk); #1;
            checks = checks + 1;
            if (!halted) begin
                errors = errors + 1;
                $display("FAIL: program did not reach ECALL (timeout)");
            end else
                $display("INFO: halted at pc=0x%08h after %0d cycles", dut.u_core.pc, cyc);

            chk_reg(0, 32'h0);            // x0 must stay zero

            case (test)
                "sum": begin
                    chk_reg(10, 32'd55);
                    chk_mem(0,  32'd55);
                end
                "fib": begin
                    chk_reg(10, 32'd610);
                    chk_mem(0,  32'd0);   chk_mem(1,  32'd1);   chk_mem(2,  32'd1);
                    chk_mem(3,  32'd2);   chk_mem(4,  32'd3);   chk_mem(5,  32'd5);
                    chk_mem(6,  32'd8);   chk_mem(7,  32'd13);  chk_mem(8,  32'd21);
                    chk_mem(9,  32'd34);  chk_mem(10, 32'd55);  chk_mem(11, 32'd89);
                    chk_mem(12, 32'd144); chk_mem(13, 32'd233); chk_mem(14, 32'd377);
                    chk_mem(15, 32'd610);
                end
                "loadstore": begin
                    chk_reg(10, 32'hA1B2C3D4);   // lw
                    chk_reg(11, 32'hFFFFFFD4);   // lb  (sign-extended)
                    chk_reg(12, 32'h000000D4);   // lbu
                    chk_reg(13, 32'hFFFFA1B2);   // lh  (sign-extended)
                    chk_reg(14, 32'h0000A1B2);   // lhu
                    chk_reg(15, 32'hFFFFFFC3);   // lb  offset 1
                    chk_reg(16, 32'h000000A1);   // lbu offset 3
                    chk_reg(17, 32'h00005A00);   // after sb at offset 5
                    chk_reg(8,  32'hBEEF0000);   // after sh at offset 10
                    chk_mem(0,  32'hA1B2C3D4);
                    chk_mem(1,  32'h00005A00);
                    chk_mem(2,  32'hBEEF0000);
                end
                "alu_branch": begin
                    chk_reg(8,  32'h0000000B);   // add
                    chk_reg(9,  32'h00000013);   // sub
                    chk_reg(18, 32'h0000000C);   // and
                    chk_reg(19, 32'hFFFFFFFF);   // or
                    chk_reg(20, 32'hFFFFFFF3);   // xor
                    chk_reg(21, 32'h00000078);   // sll
                    chk_reg(22, 32'h1FFFFFFF);   // srl
                    chk_reg(23, 32'hFFFFFFFF);   // sra
                    chk_reg(24, 32'h00000001);   // slt
                    chk_reg(25, 32'h00000000);   // sltu
                    chk_reg(26, 32'hFFFFFFFB);   // addi
                    chk_reg(27, 32'h0000005A);   // xori
                    chk_reg(28, 32'h000000F0);   // slli
                    chk_reg(29, 32'h0000000F);   // srli
                    chk_reg(30, 32'hFFFFFFFE);   // srai
                    chk_reg(31, 32'h00000001);   // slti
                    chk_reg(5,  32'h00000007);   // branch counter (6 taken + 1 not-taken pair)
                    chk_reg(6,  32'h12345000);   // lui
                    chk_reg(7,  32'h000000A8);   // auipc (pc of the auipc instruction)
                    chk_reg(1,  32'h000000B0);   // ra written by jal
                    chk_reg(13, 32'h0000004E);   // 77 from func + 1 after return (jalr)
                end
                default: begin
                    errors = errors + 1;
                    $display("FAIL: unknown +TEST=%0s", test);
                end
            endcase
        end

        $display("--------------------------------------------------");
        if (errors == 0) $display("RESULT: PASS  test=%0s  (%0d checks)", test, checks);
        else             $display("RESULT: FAIL  test=%0s  (%0d of %0d checks failed)", test, errors, checks);
        $display("--------------------------------------------------");
        $finish;
    end
endmodule
