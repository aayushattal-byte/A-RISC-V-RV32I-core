# Vivado batch flow:  vivado -mode batch -source fpga/build.tcl   (run from repo root)
# Produces build/rv32i_arty_s7.bit
set part   xc7s50csga324-1          ;# Arty S7-50; use xc7s25csga324-1 for the S7-25
set top    fpga_top
set outdir build
file mkdir $outdir

read_verilog [glob rtl/*.v]
read_xdc fpga/arty_s7.xdc

set hex [file normalize sim/hex/demo_uart_led.hex]
synth_design -top $top -part $part -generic INIT_FILE=\"$hex\"
opt_design
place_design
route_design

report_utilization    -file $outdir/utilization.rpt
report_timing_summary -file $outdir/timing.rpt
write_bitstream -force $outdir/rv32i_arty_s7.bit
puts "Bitstream: $outdir/rv32i_arty_s7.bit"
