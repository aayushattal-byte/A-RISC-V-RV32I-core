## Constraints for Digilent Arty S7-50 (XC7S50-CSGA324-1).
## !! VERIFY every PACKAGE_PIN against Digilent's master XDC for YOUR board revision
## !! (Arty S7-25 uses the same pin names; other Spartan-7 boards need different pins).

## 100 MHz oscillator
set_property -dict { PACKAGE_PIN R2  IOSTANDARD SSTL135 } [get_ports clk100]
create_clock -name sys_clk -period 10.00 [get_ports clk100]

## Reset = push-button BTN0 (active high)
set_property -dict { PACKAGE_PIN G15 IOSTANDARD LVCMOS33 } [get_ports btn_rst]

## LEDs LD2..LD5
set_property -dict { PACKAGE_PIN E18 IOSTANDARD LVCMOS33 } [get_ports {led[0]}]
set_property -dict { PACKAGE_PIN F13 IOSTANDARD LVCMOS33 } [get_ports {led[1]}]
set_property -dict { PACKAGE_PIN E13 IOSTANDARD LVCMOS33 } [get_ports {led[2]}]
set_property -dict { PACKAGE_PIN H15 IOSTANDARD LVCMOS33 } [get_ports {led[3]}]

## USB-UART bridge: FPGA TX -> PC  (called uart_rxd_out in Digilent's XDC)
set_property -dict { PACKAGE_PIN R12 IOSTANDARD LVCMOS33 } [get_ports uart_txd]

set_false_path -from [get_ports btn_rst]
